# Evaluation logic
