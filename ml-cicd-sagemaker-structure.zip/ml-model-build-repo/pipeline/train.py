# Training logic
