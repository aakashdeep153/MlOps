# Model registration logic
