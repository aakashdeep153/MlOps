# Preprocessing logic
