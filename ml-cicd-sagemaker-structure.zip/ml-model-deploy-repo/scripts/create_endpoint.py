# Helper script to create endpoint
